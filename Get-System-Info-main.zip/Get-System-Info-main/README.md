# Get-System-Info  GUI
A simple way to get your system/computer information, about os, manufactured, model and more with also a nice GUI.
The only thing you need to do is put in your terminal: pip install WMI
to install a library with windows-management-information.
